
import 'package:flutter/material.dart';

void main() => runApp(SaniMarketApp());

class SaniMarketApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'سانی مارکت',
      theme: ThemeData(
        primarySwatch: Colors.teal,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomePage(),
    );
  }
}

class Product {
  final String name;
  final int price;
  final String category;

  Product(this.name, this.price, this.category);
}

final List<Product> products = [
  Product("شیر کم‌چرب 1 لیتری", 17000, "لبنیات"),
  Product("ماست موسیر", 23500, "لبنیات"),
  Product("پنیر سفید سنتی", 29000, "لبنیات"),
  Product("نان تست سبوس‌دار", 22000, "نان و غلات"),
  Product("برنج طارم 5 کیلویی", 280000, "نان و غلات"),
  Product("آرد گندم 1 کیلویی", 14500, "نان و غلات"),
  Product("چیپس نمکی", 12000, "تنقلات"),
  Product("شکلات مغزدار", 19800, "تنقلات"),
  Product("پفک نمکی", 9000, "تنقلات"),
  Product("سیب قرمز", 38000, "میوه"),
  Product("موز", 52000, "میوه"),
  Product("خیار سبز", 26000, "میوه"),
];

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Map<String, List<Product>> grouped = {};
    for (var product in products) {
      grouped.putIfAbsent(product.category, () => []).add(product);
    }

    return Scaffold(
      appBar: AppBar(title: Text('سانی مارکت')),
      body: ListView(
        children: grouped.entries.map((entry) {
          return ExpansionTile(
            title: Text(entry.key),
            children: entry.value
                .map((product) => ListTile(
                      title: Text(product.name),
                      trailing: Text('${product.price} تومان'),
                    ))
                .toList(),
          );
        }).toList(),
      ),
    );
  }
}
